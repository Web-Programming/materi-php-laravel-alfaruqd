<?php
for ($i = 1; $i <= 5; $i++) {
    echo "Perkalian $i:" . PHP_EOL;
    for ($j = 1; $j <= 10; $j++) {
        $hasil = $i * $j;
        echo "$i x $j = $hasil" . PHP_EOL;
    }
    echo PHP_EOL; 
}
?>